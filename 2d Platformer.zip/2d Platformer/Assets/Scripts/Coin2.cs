﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin2 : MonoBehaviour
{

    public SimplePlatformController controller;
    // Use this for initialization
    void Start()
    {
        int coinFlip = Random.Range(0, 2);
        if (coinFlip > 0)
            Destroy(gameObject);
        GameObject gameControllerObject = GameObject.FindWithTag("Player");
        if (gameControllerObject != null)
            controller = gameControllerObject.GetComponent<SimplePlatformController>();
    }

    // Update is called once per frame
    void Update()
    {

    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {

            controller.AddScore(3);
            Destroy(gameObject);
        }


    }
}
